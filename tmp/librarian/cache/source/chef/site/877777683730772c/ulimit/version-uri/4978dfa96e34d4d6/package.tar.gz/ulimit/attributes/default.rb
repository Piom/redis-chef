default['ulimit']['pam_su_template_cookbook'] = nil
