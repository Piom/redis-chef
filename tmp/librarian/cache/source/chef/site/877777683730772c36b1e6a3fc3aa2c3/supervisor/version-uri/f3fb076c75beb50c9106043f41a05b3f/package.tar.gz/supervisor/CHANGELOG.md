## v0.4.0:

* [COOK-2157] - add `inet_http_server` and logfile config settings

## v0.3.0:

* [COOK-2053] - Supervisor cookbook missing stopasgroup

## v0.2.0:

* [COOK-1720] - support for 'minfds' or 'minprocs' parameters
